import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {

  applicants:any[];
  applicationId:string="";
  statusResult:string="";
  constructor(private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.httpClient.get("assets/project.json").subscribe((data: any): void => {
      this.applicants = data.applicant;
    });
  }

  checkStatus(){
    var applicationId = this.applicationId;
    var statusResult = "";
    this.applicants.forEach(function(value){
      if(value.applicantId == applicationId){
        statusResult = applicationId+" is "+value.status;
      }
    });
    this.statusResult = statusResult;
    if(this.statusResult == ""){
      this.statusResult = this.applicationId+" does not exists";
    }
  }
}
