import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-apply-course',
  templateUrl: './apply-course.component.html',
  styleUrls: ['./apply-course.component.css']
})
export class ApplyCourseComponent implements OnInit {

  targetCourse:number;
  courses:any[];
  applicantName:string="";
  applicantDOB:string="";
  highestQualification:string="";
  marks:string="";
  goals:string="";
  email:string="";
  errorMsg:string="";
  successMsg:string="";
  constructor(private router: ActivatedRoute,private httpClient: HttpClient) {
    if(this.router.snapshot.queryParamMap.has('id')){
      this.targetCourse = parseInt(this.router.snapshot.queryParamMap.get('id'));
    }
  }

  ngOnInit(): void {
    this.httpClient.get("assets/project.json").subscribe((data: any): void => {
      this.courses = data.programsOffered;
    });
  }

  apply(){
    this.errorMsg = "";
    this.successMsg = "";
    if(this.applicantName=="" || this.applicantDOB=="" || this.highestQualification=="" || this.marks=="" || this.goals=="" || this.email==""){
      this.errorMsg = "All the fields are Mandatory";
    }
    else{
      this.successMsg = "Application Submitted";
      this.applicantName="";
      this.applicantDOB="";
      this.highestQualification="";
      this.marks="";
      this.goals="";
      this.email="";
    }
  }
}
